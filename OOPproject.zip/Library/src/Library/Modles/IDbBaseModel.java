package Library.Modles;

public interface IDbBaseModel {
    public int GetId();
    public String GetTableQuery();
    public String GetInsertQuery();
    public String GetUpdateQuery();
    public String GetDeleteQuery();
    public String GetQuery();
}
