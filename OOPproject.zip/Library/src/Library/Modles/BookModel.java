package Library.Modles;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Library.Utils;

public class BookModel implements IDbBaseModel  {
    public int Id;
    public String Name;
    public String Auther;
    public String Category;
    public int Pages;
    public int Section;
    public float Price;

    @Override
    public int GetId() {
        return Id;
    }

    @Override
    public String GetTableQuery() {
        String sql = "CREATE TABLE Books ("
            + "ID	INTEGER NOT NULL,"
            + "Name	TEXT NOT NULL,"
            + "Auther	TEXT NOT NULL,"
            + "Category	TEXT NOT NULL,"
            + "Pages	INTEGER NOT NULL,"
            + "Section	INTEGER NOT NULL,"
            + "Price	REAL NOT NULL,"
            + "PRIMARY KEY(ID AUTOINCREMENT)"
            + ");";
        return sql;
    }

    @Override
    public String GetInsertQuery() {
        String sql = "INSERT INTO Books " + "(ID, Name, Auther, Category, Pages, Section, Price) VALUES "
                + "(null, '" + Name + "', '" + Auther + "', '" + Category + "', " + Pages + ", " + Section + ", " + Price + ");";
        return sql;
    }

    @Override
    public String GetUpdateQuery() {
        String sql = "UPDATE Books SET "
                + "Name = '"+ Name + "', "
                + "Auther = '" + Auther + "', "
                + "Category = '" + Category + "', "
                + "Pages = '" + Pages + "', "
                + "Section = '" + Section + "', "
                + "Price = '" + Price + "' "
                + "WHERE ID=" + GetId() + ";";
        return sql;
    }

    @Override
    public String GetDeleteQuery() {
        String sql = "DELETE from Books WHERE ID=" + GetId() + ";";
        return sql;
    }

    @Override
    public String GetQuery() {
        String sql = "SELECT * FROM Books WHERE ID=" + GetId() + ";";
        return sql;
    }

    
    public static BookModel GetByName(String bookName) {
        BookModel ret = new BookModel();

        String sql = "SELECT * FROM Books WHERE UserName='" + bookName + "';";
        ResultSet rs = Utils.Db.ExecSelectCommand(sql);

        try {
            if (rs == null || !rs.next())
                return null;

            ret.Id       = rs.getInt("ID");
            ret.Name     = rs.getString("Name");
            ret.Auther   = rs.getString("Auther");
            ret.Category = rs.getString("Category");
            ret.Pages    = rs.getInt("Pages");
            ret.Section  = rs.getInt("Section");
            ret.Price    = rs.getFloat("Price");

            rs.getStatement().close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return ret;
    }

    public static ArrayList<BookModel> GetBooks() {
        ArrayList<BookModel> ret = new ArrayList<BookModel>();

        String sql = "SELECT * FROM Books";
        ResultSet rs = Utils.Db.ExecSelectCommand(sql);

        try {
            if (rs == null)
                return null;

            while (rs.next()) {
                BookModel user = new BookModel();

                user.Id = rs.getInt("ID");
                user.Name = rs.getString("Name");
                user.Auther = rs.getString("Auther");
                user.Category = rs.getString("Category");
                user.Pages = rs.getInt("Pages");
                user.Section = rs.getInt("Section");
                user.Price = rs.getFloat("Price");

                ret.add(user);
            }

            rs.getStatement().close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return ret;
        }

        return ret;
    }

    public static BookModel GetById(int id) {
        BookModel ret = new BookModel();

        String sql = "SELECT * FROM Books WHERE ID='" + id + "';";
        ResultSet rs = Utils.Db.ExecSelectCommand(sql);

        try {
            if (rs == null || !rs.next())
                return null;

            ret.Id       = rs.getInt("ID");
            ret.Name     = rs.getString("Name");
            ret.Auther   = rs.getString("Auther");
            ret.Category = rs.getString("Category");
            ret.Pages    = rs.getInt("Pages");
            ret.Section  = rs.getInt("Section");
            ret.Price    = rs.getFloat("Price");

            rs.getStatement().close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return ret;
    }
}
