package Library.Modles;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Library.Utils;

public class UserModel implements IDbBaseModel {
    public int Id;
    public String UserName;
    public String Password;
    public String Name;
    public int Role; // 0 = user, 1 = admin
    public ArrayList<BookModel> RentedBooks;

    public UserModel() {
        RentedBooks = new ArrayList<BookModel>();
    }

    @Override
    public int GetId() {
        return Id;
    }

    @Override
    public String GetTableQuery() {
        String sql = "CREATE TABLE Users ("
                + "ID INTEGER NOT NULL,"
                + "UserName TEXT NOT NULL, "
                + "Password TEXT NOT NULL, "
                + "Name INTEGER NOT NULL, "
                + "Role INTEGER NOT NULL, "
                + "RentedBooks TEXT NOT NULL, "
                + "PRIMARY KEY(ID AUTOINCREMENT)"
                + ")";
        return sql;
    }

    @Override
    public String GetInsertQuery() {
        String sql = "INSERT INTO Users " + "(ID, UserName, Password, Name, Role, RentedBooks) VALUES " + "(null, '" + UserName
                + "', '" + Password + "', '" + Name + "', " + Role + ", '" + GetRentedBooksFormated() + "');";
        return sql;
    }

    @Override
    public String GetUpdateQuery() {
        String sql = "UPDATE Users SET " + "UserName = '" + UserName + "', " + "Password = '" + Password + "', "
                + "Name = '" + Name + "', " + "Role = " + Role + ", RentedBooks = '" + GetRentedBooksFormated() + "'" + " WHERE ID=" + GetId() + ";";
        return sql;
    }

    @Override
    public String GetDeleteQuery() {
        String sql = "DELETE from Users WHERE ID=" + GetId() + ";";
        return sql;
    }

    @Override
    public String GetQuery() {
        String sql = "SELECT * FROM Users WHERE ID=" + GetId() + ";";
        return sql;
    }

    private String GetRentedBooksFormated() {
        ArrayList<String> ids = new ArrayList<>();

        for (BookModel b : RentedBooks) {
            ids.add(b.Id + "");
        }

        return String.join(",", ids);
    }

    private static ArrayList<BookModel> GetRentedBooks(String rentedBooks) {
        ArrayList<BookModel> ret = new ArrayList<>();

        if (rentedBooks.equals(null) || rentedBooks.equals(""))
            return ret;

        String[] ids = rentedBooks.split(",");
        for (String id : ids) {
            ret.add(BookModel.GetById(Integer.parseInt(id)));
        }

        return ret;
    }

    public static UserModel GetByUserName(String userName) {
        UserModel ret = new UserModel();

        String sql = "SELECT * FROM Users WHERE UserName='" + userName + "';";
        ResultSet rs = Utils.Db.ExecSelectCommand(sql);

        try {
            if (rs == null || !rs.next())
                return null;

            ret.Id = rs.getInt("ID");
            ret.Name = rs.getString("Name");
            ret.UserName = rs.getString("UserName");
            ret.Password = rs.getString("Password");
            ret.Role = rs.getInt("Role");
            ret.RentedBooks = GetRentedBooks(rs.getString("RentedBooks"));

            rs.getStatement().close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return ret;
    }

    public static ArrayList<UserModel> GetUsers() {
        ArrayList<UserModel> ret = new ArrayList<UserModel>();

        String sql = "SELECT * FROM Users";
        ResultSet rs = Utils.Db.ExecSelectCommand(sql);

        try {
            if (rs == null)
                return null;

            while (rs.next()) {
                UserModel user = new UserModel();

                user.Id = rs.getInt("ID");
                user.Name = rs.getString("Name");
                user.UserName = rs.getString("UserName");
                user.Password = rs.getString("Password");
                user.Role = rs.getInt("Role");
                user.RentedBooks = GetRentedBooks(rs.getString("RentedBooks"));

                ret.add(user);
            }

            rs.getStatement().close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return ret;
        }

        return ret;
    }

}
