package Library;

import Library.Modles.UserModel;
import Library.Services.DbManager;

public class Utils {
    public static DbManager Db = new DbManager();
    public static UserModel User = null;
}
