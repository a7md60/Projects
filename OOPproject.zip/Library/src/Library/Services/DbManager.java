package Library.Services;

import java.sql.*;

import Library.Modles.IDbBaseModel;

public class DbManager {
    private String DbName = "LibDB.db";
    private Connection conn = null;

    public boolean ExecCommand(String query) {
        Statement stmt;

        if (conn == null)
            return false;

        try {
            stmt = conn.createStatement();
            stmt.executeUpdate(query);
            stmt.close();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public ResultSet ExecSelectCommand(String query) {
        Statement stmt;

        if (conn == null)
            return null;

        try {
            stmt = conn.createStatement();
            return stmt.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean Connect() {
        // Connect to database (Create if not exist)
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:" + DbName);
            conn.setAutoCommit(true);
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            return false;
        }

        return true;
    }

    public void Close() {
        if (conn == null)
            return;

        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean CreateTable(IDbBaseModel model) {
        return ExecCommand(model.GetTableQuery());
    }

    public boolean Insert(IDbBaseModel model) {
        return ExecCommand(model.GetInsertQuery());
    }

    public boolean Update(IDbBaseModel model) {
        return ExecCommand(model.GetUpdateQuery());
    }

    public boolean Delete(IDbBaseModel model) {
        return ExecCommand(model.GetDeleteQuery());
    }

    public ResultSet Get(IDbBaseModel model) {
        return ExecSelectCommand(model.GetQuery());
    }

    public ResultSet Get(String query) {
        return ExecSelectCommand(query);
    }

}
