package Library;

import Library.Modles.BookModel;
import Library.Modles.UserModel;
import Library.UI.Login;

// Entry Point
public class Program {
    public static void main(String[] args) {
        if (!InitDataBase()) {
            Utils.Db.Close();
            System.exit(-1);
            return;
        }

        Login.main(null);
    }

    public static boolean InitDataBase() {
        // Init DataBase
        if (!Utils.Db.Connect()) {
            System.out.println("Database faild to connect.");
            return false;
        }

        // Tables
        if (!Utils.Db.CreateTable(new UserModel()))
            System.out.println("Table faild to create.");

        if (!Utils.Db.CreateTable(new BookModel()))
            System.out.println("Table faild to create.");
        
        return true;

    }
}
