package Library.UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;

import Library.Utils;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class MainMenu {
    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainMenu window = new MainMenu();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public MainMenu() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setResizable(false);
        frame.setBounds(100, 100, 683, 540);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Library - MainMenu");
        frame.setLocationRelativeTo(null);
        
        JPanel panel = new JPanel();
        panel.setBackground(Color.DARK_GRAY);
        panel.setForeground(Color.WHITE);
        panel.setLayout(null);

        JButton btnAddbook = new JButton("Book Manager");
        btnAddbook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (Utils.User.Role == 0)
                {
                    JOptionPane.showMessageDialog(null, "You dont have permissions", "Access denied", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                BookManager.main(null);
                frame.dispose();
            }
        });
        btnAddbook.setBounds(10, 54, 218, 32);
        panel.add(btnAddbook);

        JButton btnNewButton = new JButton("Issue A Book");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                IssueAbook.main(null);
                frame.dispose();
            }
        });
        btnNewButton.setBounds(10, 97, 218, 32);
        panel.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Return Books");
        btnNewButton_1.setBounds(10, 140, 218, 32);
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                ReturnBook.main(null);
                frame.dispose();
            }
        });
        panel.add(btnNewButton_1);

        JButton btnUserList = new JButton("Users Manager");
        btnUserList.setBounds(10, 11, 218, 32);
        btnUserList.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (Utils.User.Role == 0)
                {
                    JOptionPane.showMessageDialog(null, "You dont have permissions", "Access denied", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                UsersManager.main(null);
                frame.dispose();
            }
        });
        panel.add(btnUserList);

        JButton btnNewButton_5 = new JButton("Logout");
        btnNewButton_5.setBounds(10, 466, 218, 23);
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                Utils.User = null;
                Login.main(null);
                frame.dispose();
            }
        });
        panel.add(btnNewButton_5);
        GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
        groupLayout.setHorizontalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addComponent(panel, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
        );
        groupLayout.setVerticalGroup(
        	groupLayout.createParallelGroup(Alignment.LEADING)
        		.addComponent(panel, GroupLayout.PREFERRED_SIZE, 511, GroupLayout.PREFERRED_SIZE)
        );
        frame.getContentPane().setLayout(groupLayout);
    }
}
