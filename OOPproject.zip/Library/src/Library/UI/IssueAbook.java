package Library.UI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import Library.Utils;
import Library.Modles.BookModel;

public class IssueAbook {

    private JFrame frmLibraryIssue;
    private BookModel selectedBook;

    int row;
    ArrayList<BookModel> BookList;
    DefaultTableModel dtm;
    String header[] = new String[] { "Id", "Name", "Author", "Category", "Pages", "Section", "Price" };
    JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    IssueAbook window = new IssueAbook();
                    window.frmLibraryIssue.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * @wbp.parser.entryPoint
     */
    public IssueAbook() {
        initialize();
        BookList = BookModel.GetBooks();
        table.setModel(dtm);
        DisplayList();
    }

    public void DisplayList() {
        dtm.setRowCount(0);
        for (int i = 0; i < BookList.size(); i++) {
            BookModel book = BookList.get(i);

            Object[] obj = { book.Id, book.Name, book.Auther, book.Category, book.Pages, book.Section, book.Price };
            dtm.addRow(obj);
        }
    }

    private void initialize() {
        frmLibraryIssue = new JFrame();
        frmLibraryIssue.setResizable(false);
        frmLibraryIssue.setTitle("Library - Issue A Book");
        frmLibraryIssue.setBounds(100, 100, 489, 426);
        frmLibraryIssue.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmLibraryIssue.getContentPane().setLayout(null);
        frmLibraryIssue.setLocationRelativeTo(null);

        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(10, 11, 454, 311);
        frmLibraryIssue.getContentPane().add(scrollPane_1);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane_1.setRowHeaderView(scrollPane);

        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                row = table.getSelectedRow();
                selectedBook = BookList.get(row);
            }
        });
        scrollPane.setViewportView(table);
        dtm = new DefaultTableModel(header, 0);

        JButton btnIssue = new JButton("Issue");
        btnIssue.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (selectedBook == null) {
                    JOptionPane.showMessageDialog(null, "Select a book first.", "Try again", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                boolean found = false;
                for (BookModel book : Utils.User.RentedBooks) {
                    if (book.Id == selectedBook.Id) {
                        found = true;
                        break;
                    }
                }

                if (found)
                {
                    JOptionPane.showMessageDialog(null, "You already rented that book.", "Try again", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update
                Utils.User.RentedBooks.add(selectedBook);
                Utils.Db.Update(Utils.User);

                JOptionPane.showMessageDialog(null, "Book rented successfuly", "YAY", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        btnIssue.setBounds(10, 334, 204, 44);
        frmLibraryIssue.getContentPane().add(btnIssue);

        JButton btnback = new JButton("Back");
        btnback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                MainMenu.main(null);
                frmLibraryIssue.dispose();
            }
        });
        btnback.setBounds(238, 333, 226, 45);
        frmLibraryIssue.getContentPane().add(btnback);
    }
}
