package Library.UI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import Library.Utils;
import Library.Modles.BookModel;

public class ReturnBook {

    private JFrame frmLibraryReturn;

    int row;
    DefaultTableModel dtm;
    String header[] = new String[] { "Id", "Name", "Author", "Category", "pages", "Section", "Price" };
    JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ReturnBook window = new ReturnBook();
                    window.frmLibraryReturn.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * @wbp.parser.entryPoint
     */
    public ReturnBook() {
        initialize();
        table.setModel(dtm);
        DisplayList();
    }

    public void DisplayList() {
        dtm.setRowCount(0);
        for (int i = 0; i < Utils.User.RentedBooks.size(); i++) {
            BookModel book = Utils.User.RentedBooks.get(i);

            Object[] obj = { book.Id, book.Name, book.Auther, book.Category, book.Pages, book.Section, book.Price };
            dtm.addRow(obj);
        }
    }

    private void initialize() {
        frmLibraryReturn = new JFrame();
        frmLibraryReturn.setResizable(false);
        frmLibraryReturn.setTitle("Library - Return Book");
        frmLibraryReturn.setBounds(100, 100, 776, 425);
        frmLibraryReturn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmLibraryReturn.getContentPane().setLayout(null);
        frmLibraryReturn.setLocationRelativeTo(null);
        
        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(10, 11, 732, 314);
        frmLibraryReturn.getContentPane().add(scrollPane_1);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane_1.setViewportView(scrollPane);

        table = new JTable();

        scrollPane.setViewportView(table);
        dtm = new DefaultTableModel(header, 0);

        JButton btnReturn = new JButton("Return book");
        btnReturn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                row = table.getSelectedRow();
                int rowId = (Integer) dtm.getValueAt(row, 0);
                BookModel selectedBook = null;

                for (BookModel book : Utils.User.RentedBooks) {
                    if (book.Id == rowId) {
                        selectedBook = book;
                        break;
                    }
                }

                if (selectedBook == null) {
                    JOptionPane.showMessageDialog(null, "You dont have permissions", "Access denied", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int selectedId = selectedBook.Id;
                Utils.User.RentedBooks.removeIf(b -> b.Id == selectedId);
                Utils.Db.Update(Utils.User);
                DisplayList();
            }
        });
        btnReturn.setBounds(10, 336, 159, 40);
        frmLibraryReturn.getContentPane().add(btnReturn);

        JButton btnback = new JButton("back");
        btnback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                MainMenu.main(null);
                frmLibraryReturn.dispose();
            }
        });
        btnback.setBounds(179, 336, 133, 40);
        frmLibraryReturn.getContentPane().add(btnback);
    }
}
