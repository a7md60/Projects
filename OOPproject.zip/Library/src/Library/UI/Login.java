package Library.UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Library.Utils;
import Library.Modles.UserModel;

public class Login {
    private JFrame frame;
    private JPasswordField pass;
    private JTextField userN;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login window = new Login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Login() {
        initialize();
    }

    private void initialize() {        
        frame = new JFrame();
        frame.setBounds(200, 100, 300, 140);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setResizable(false);
        frame.setTitle("Library - Login");
        frame.setLocationRelativeTo(null);

        JLabel lblUserName = new JLabel("Username");
        lblUserName.setBounds(10, 10, 62, 21);
        frame.getContentPane().add(lblUserName);

        userN = new JTextField();
        userN.setBounds(100, 12, 180, 19);
        frame.getContentPane().add(userN);
        userN.setColumns(10);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setBounds(10, 44, 62, 13);
        frame.getContentPane().add(lblPassword);

        pass = new JPasswordField();
        pass.setBounds(100, 40, 180, 19);
        frame.getContentPane().add(pass);

        JButton btnLogIn = new JButton("Login");
        btnLogIn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                OnLogin();
            }
        });
        btnLogIn.setBounds(10, 70, 85, 21);
        frame.getContentPane().add(btnLogIn);

        JButton btnReset = new JButton("Reset");
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                OnReset();
            }
        });
        btnReset.setBounds(102, 70, 85, 21);
        frame.getContentPane().add(btnReset);

        JButton btnReg = new JButton("Register");
        btnReg.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                frame.dispose();
                Register.main(null);
            }
        });
        btnReg.setBounds(192, 70, 85, 21);
        frame.getContentPane().add(btnReg);
    }

    private void OnLogin() {
        String username = userN.getText();
        String password = new String(pass.getPassword());

        UserModel user = UserModel.GetByUserName(username);
        if (user != null)
        {
            if (username.equals(user.UserName) && password.equals(user.Password))
            {
                MainMenu.main(null);
                frame.dispose();
                Utils.User = user;
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Your username or password is incorrect", "Try again", JOptionPane.ERROR_MESSAGE);
        pass.setText(null);
    }

    private void OnReset() {
        userN.setText(null);
        pass.setText(null);
    }
}
