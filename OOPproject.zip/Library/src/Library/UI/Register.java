package Library.UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

import Library.Utils;
import Library.Modles.UserModel;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Register {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register window = new Register();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Register() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 255, 173);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
        frame.setResizable(false);
        frame.setTitle("Libaray - Register");
        frame.setLocationRelativeTo(null);

        JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(10, 14, 82, 16);
		frame.getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(102, 12, 134, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
        JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(10, 39, 82, 19);
		frame.getContentPane().add(lblNewLabel_1);

		textField_1 = new JTextField();
		textField_1.setBounds(102, 38, 134, 19);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
        JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(10, 70, 82, 16);
		frame.getContentPane().add(lblNewLabel_2);

		textField_2 = new JTextField();
		textField_2.setBounds(102, 68, 134, 19);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setBounds(10, 97, 104, 33);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                UserModel regUser = new UserModel();
                regUser.Name = textField.getText();
                regUser.UserName = textField_1.getText();
                regUser.Password = textField_2.getText();
                regUser.Role = 0;

                if (!Utils.Db.Insert(regUser))
                {
                    JOptionPane.showMessageDialog(null, "Can't register", "Try again", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                JOptionPane.showMessageDialog(null, "Registerd !!", "Yay", JOptionPane.INFORMATION_MESSAGE);
                frame.dispose();
                Login.main(null);
            }
        });
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
                Login.main(null);
			}
		});
		btnNewButton_1.setBounds(139, 98, 97, 32);
		frame.getContentPane().add(btnNewButton_1);
	}
}
