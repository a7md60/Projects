package Library.UI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import Library.Utils;
import Library.Modles.BookModel;

import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.DefaultComboBoxModel;

public class BookManager {
    private JFrame frame;
    JTextField bookId;
    JTextField bookName;
    JTextField bookAuthor;
    JTextField bookPrice;
    JTextField bookPage;
    JTextField bookSection;
    JComboBox<String> bookCategory;

    int row;
    ArrayList<BookModel> booksList;
    DefaultTableModel dtm;
    String header[] = new String[] { "Id", "Name", "Author", "Category", "Pages", "Section", "Price" };
    JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BookManager window = new BookManager();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public BookManager() {
        initialize();

        table.setModel(dtm);
        DisplayList();
    }

    public void DisplayList() {
        booksList = BookModel.GetBooks();
        dtm.setRowCount(0);
        for (int i = 0; i < booksList.size(); i++) {
            BookModel book = booksList.get(i);
            Object[] obj = { book.Id, book.Name, book.Auther, book.Category, book.Pages, book.Section, book.Price };
            dtm.addRow(obj);
        }
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 777, 382);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setResizable(false);
        frame.setTitle("Library - Books");
        frame.setLocationRelativeTo(null);

        JLabel bookIdLbl = new JLabel("Id");
        bookIdLbl.setBounds(10, 14, 72, 13);
        frame.getContentPane().add(bookIdLbl);

        JLabel bookNameLbl = new JLabel("Name");
        bookNameLbl.setBounds(10, 40, 72, 13);
        frame.getContentPane().add(bookNameLbl);

        JLabel bookAuthorLbl = new JLabel("Author");
        bookAuthorLbl.setBounds(10, 70, 72, 13);
        frame.getContentPane().add(bookAuthorLbl);

        JLabel bookPriceLbl = new JLabel("Price");
        bookPriceLbl.setBounds(10, 98, 40, 13);
        frame.getContentPane().add(bookPriceLbl);

        JLabel bookPageLbl = new JLabel("Pages");
        bookPageLbl.setBounds(10, 128, 72, 13);
        frame.getContentPane().add(bookPageLbl);

        JLabel bookSectionLbl = new JLabel("Section");
        bookSectionLbl.setBounds(10, 158, 72, 13);
        frame.getContentPane().add(bookSectionLbl);

        JLabel bookCategoryLbl = new JLabel("Category");
        bookCategoryLbl.setBounds(10, 188, 72, 13);
        frame.getContentPane().add(bookCategoryLbl);

        bookId = new JTextField();
        bookId.setBounds(84, 10, 143, 19);
        frame.getContentPane().add(bookId);
        bookId.setColumns(10);

        bookName = new JTextField();
        bookName.setBounds(84, 36, 143, 19);
        frame.getContentPane().add(bookName);
        bookName.setColumns(10);

        bookAuthor = new JTextField();
        bookAuthor.setBounds(84, 66, 143, 19);
        frame.getContentPane().add(bookAuthor);
        bookAuthor.setColumns(10);

        bookPrice = new JTextField();
        bookPrice.setBounds(84, 94, 143, 19);
        frame.getContentPane().add(bookPrice);
        bookPrice.setColumns(10);

        bookPage = new JTextField();
        bookPage.setBounds(84, 124, 143, 19);
        frame.getContentPane().add(bookPage);
        bookPage.setColumns(10);

        bookSection = new JTextField();
        bookSection.setBounds(84, 154, 143, 19);
        frame.getContentPane().add(bookSection);
        bookSection.setColumns(10);

        bookCategory = new JComboBox<String>();
        bookCategory.setModel(new DefaultComboBoxModel<String>(new String[] { "english", "physics", "chemistry", "comics", "drama", "poem" }));
        bookCategory.setBounds(84, 184, 143, 21);
        frame.getContentPane().add(bookCategory);

        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(237, 5, 515, 334);
        frame.getContentPane().add(scrollPane_1);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane_1.setViewportView(scrollPane);

        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                row = table.getSelectedRow();

                bookId.setText(dtm.getValueAt(row, 0).toString());
                bookName.setText(dtm.getValueAt(row, 1).toString());
                bookAuthor.setText(dtm.getValueAt(row, 2).toString());
                bookCategory.setSelectedItem(dtm.getValueAt(row, 3));
                bookPage.setText(dtm.getValueAt(row, 4).toString());
                bookSection.setText(dtm.getValueAt(row, 5).toString());
                bookPrice.setText(dtm.getValueAt(row, 6).toString());
            }
        });
        scrollPane.setViewportView(table);
        dtm = new DefaultTableModel(header, 0);

        JButton btnadd = new JButton("add");
        btnadd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                BookModel book = new BookModel();
                book.Name = bookName.getText();
                book.Auther = bookAuthor.getText();
                book.Category = bookCategory.getSelectedItem().toString();
                book.Pages = Integer.parseInt(bookPage.getText());
                book.Section = Integer.parseInt(bookSection.getText());
                book.Price = Float.parseFloat(bookPrice.getText());

                Utils.Db.Insert(book);
                DisplayList();
            }
        });
        btnadd.setBounds(10, 216, 106, 59);
        frame.getContentPane().add(btnadd);

        JButton btnedit = new JButton("edit");
        btnedit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                BookModel book = booksList.get(row);
                
                book.Name = bookName.getText();
                book.Auther = bookAuthor.getText();
                book.Category = bookCategory.getSelectedItem().toString();
                book.Pages = Integer.parseInt(bookPage.getText());
                book.Section = Integer.parseInt(bookSection.getText());
                book.Price = Float.parseFloat(bookPrice.getText());

                Utils.Db.Update(book);
                DisplayList();
            }
        });
        btnedit.setBounds(126, 216, 101, 59);
        frame.getContentPane().add(btnedit);

        JButton btndelete = new JButton("delete");
        btndelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                int choice = JOptionPane.showConfirmDialog(null, "Delete it ??", "Delete", JOptionPane.YES_NO_OPTION);
                if (choice == 0) {
                    BookModel book = booksList.get(row);
                    Utils.Db.Delete(book);

                    dtm.removeRow(row);
                    booksList.remove(row);
                    DisplayList();
                }
            }
        });
        btndelete.setBounds(10, 286, 106, 53);
        frame.getContentPane().add(btndelete);

        JButton btnback = new JButton("back");
        btnback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                MainMenu.main(null);
                frame.dispose();
            }
        });
        btnback.setBounds(126, 286, 101, 53);
        frame.getContentPane().add(btnback);
    }
}
