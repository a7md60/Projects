package Library.UI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import Library.Utils;
import Library.Modles.UserModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UsersManager {
    private JFrame frmLibraryUser;
    private JLabel Name;
    JTextField UserID;
    JTextField yourName;
    JTextField UserName;
    JTextField yourRole3;
    JTextField yourPass;

    int row;
    ArrayList<UserModel> userList;
    DefaultTableModel dtm;
    String header[] = new String[] { "ID", "Name", "UserName", "Password", "Role" };
    JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UsersManager window = new UsersManager();
                    window.frmLibraryUser.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public UsersManager() {
        initialize();
        table.setModel(dtm);
        DisplayList();
    }

    public void DisplayList() {
        userList = UserModel.GetUsers();
        dtm.setRowCount(0);
        for (int i = 0; i < userList.size(); i++) {
            UserModel user = userList.get(i);
            Object[] obj = { user.Id, user.Name, user.UserName, user.Password, user.Role };
            dtm.addRow(obj);
        }
    }

    private void initialize() {
        frmLibraryUser = new JFrame();
        frmLibraryUser.setResizable(false);
        frmLibraryUser.setTitle("Library - User Manager");
        frmLibraryUser.setBounds(100, 100, 778, 308);
        frmLibraryUser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmLibraryUser.getContentPane().setLayout(null);
        frmLibraryUser.setLocationRelativeTo(null);

        Name = new JLabel("Name");
        Name.setBounds(10, 45, 72, 13);
        frmLibraryUser.getContentPane().add(Name);

        JLabel userName = new JLabel("username");
        userName.setBounds(10, 76, 72, 13);
        frmLibraryUser.getContentPane().add(userName);

        JLabel bookPage = new JLabel("Role");
        bookPage.setBounds(10, 106, 72, 13);
        frmLibraryUser.getContentPane().add(bookPage);

        JLabel passPage = new JLabel("Password");
        passPage.setBounds(10, 136, 72, 13);
        frmLibraryUser.getContentPane().add(passPage);

        JLabel userID = new JLabel("ID");
		userID.setBounds(10, 15, 72, 13);
		frmLibraryUser.getContentPane().add(userID);

        UserID = new JTextField();
		UserID.setBounds(73, 11, 130, 19);
		frmLibraryUser.getContentPane().add(UserID);
		UserID.setColumns(10);

        yourName = new JTextField();
        yourName.setBounds(73, 41, 130, 19);
        frmLibraryUser.getContentPane().add(yourName);
        yourName.setColumns(10);

        UserName = new JTextField();
        UserName.setBounds(73, 72, 130, 19);
        frmLibraryUser.getContentPane().add(UserName);
        UserName.setColumns(10);

        yourRole3 = new JTextField();
        yourRole3.setBounds(73, 102, 130, 19);
        frmLibraryUser.getContentPane().add(yourRole3);
        yourRole3.setColumns(10);

        yourPass = new JTextField();
        yourPass.setBounds(73, 132, 130, 19);
        frmLibraryUser.getContentPane().add(yourPass);
        yourPass.setColumns(10);

        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(214, 11, 548, 252);
        frmLibraryUser.getContentPane().add(scrollPane_1);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setEnabled(false);
        scrollPane_1.setViewportView(scrollPane);

        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                row = table.getSelectedRow();

                UserID.setText(dtm.getValueAt(row, 0).toString());
                yourName.setText(dtm.getValueAt(row, 1).toString());
                UserName.setText(dtm.getValueAt(row, 2).toString());
                yourPass.setText(dtm.getValueAt(row, 3).toString());
                yourRole3.setText(dtm.getValueAt(row, 4).toString());
            }
        });
        scrollPane.setViewportView(table);
        dtm = new DefaultTableModel(header, 0);

        JButton btnadd = new JButton("add");
        btnadd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                UserModel user = new UserModel();
                user.Name = yourName.getText();
                user.UserName = UserName.getText();
                user.Password = yourPass.getText();
                user.Role = Integer.parseInt(yourRole3.getText());

                Utils.Db.Insert(user);
                DisplayList();
            }
        });
        btnadd.setBounds(10, 160, 85, 47);
        frmLibraryUser.getContentPane().add(btnadd);

        JButton btnedit = new JButton("edit");
        btnedit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                UserModel user = userList.get(row);
                user.Name = yourName.getText();
                user.UserName = UserName.getText();
                user.Password = yourPass.getText();
                user.Role = Integer.parseInt(yourRole3.getText());

                Utils.Db.Update(user);

                DisplayList();
            }
        });
        btnedit.setBounds(115, 162, 88, 45);
        frmLibraryUser.getContentPane().add(btnedit);

        JButton btndelete = new JButton("delete");
        btndelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                int choice = JOptionPane.showConfirmDialog(null, "Delete it ??", "Delete", JOptionPane.YES_NO_OPTION);
                if (choice == 0) {
                    UserModel user = userList.get(row);
                    Utils.Db.Delete(user);

                    dtm.removeRow(row);
                    userList.remove(row);
                    DisplayList();
                }

            }
        });
        btndelete.setBounds(10, 218, 85, 45);
        frmLibraryUser.getContentPane().add(btndelete);

        JButton btnback = new JButton("back");
        btnback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                MainMenu.main(null);
                frmLibraryUser.dispose();
            }
        });
        btnback.setBounds(115, 218, 88, 45);
        frmLibraryUser.getContentPane().add(btnback);
    }
}
